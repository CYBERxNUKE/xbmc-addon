# -*- coding: utf-8 -*-
airing, alldebrid, bad_language, because_you_watched, box_office, calender, calendar_decades = 'eUeOcto', 'UBjURaL', 'tKJVTmq', 'IFWDwai', 'WzYp4H8', 'fN4GQmO', '2OJn9MC'
certifications, discover, downloads, drugs_alcohol, dvd, easynews, favourites, fen = 'aHv21HF', 'PEdc5Bh', 'KkNYKy6', 'R9alT5V', 'b9La9Ch', 'nkBuUe9', 'uCaIeC6', 'IfNMnPJ'
folder, fresh, furk, genres, github, imdb, in_progress_tvshow = 'I1JJhji', 'O2bqOfI', 'EkQfQ8u', '6QpJbS0', 'wZWNeVd', '2xNcDuj', 'BfGbQXx'
information, intheatres, item_jump, item_next, languages, lists, live = 'ODbe89r', '9660DAY', 'UCZnedu', 'Iqq0IC6', 'gxgLI0J', 'XbEEv9X', 'VmIhHM6'
most_watched, most_voted, movies, networks, new, next_episodes, nextpage = 'wG42SLp', 'aj02pjQ', 'pmyCOx7', 'pVxUSzl', 's4krx5q', '0KFvjKR', 'z442KXK'
ontheair, oscar_winners, people, planet, player, popular, premium = 'Ht6HpQO', 'AMg9mQS', 'jOBKuzO', 'NK71dGC', 'D0nCsqI', 'ngkznpf', 'inX030Z'
premiumize, realdebrid, search, settings, settings2, sex_nudity, tmdb = 'nETvpPS', 'DotYAc3', 'owsADQ4', 'RDNxy36', '4xBbqSw', 'B4NHuAp', 'bOqItvH'
tools, top, trakt, trending, trending_recent, tv, watched_1, watched_recent = 'eofrRXT', 'IOtOum6', 'xihFNwP', 'rVq7so0', 'vBwrjLV', 'R3NEEJl', 'Ps93y86', 'SacesHf'

search_history, search_imdb, search_movie, search_new, search_people, search_tmdb, search_tv = 'y1DEuvk', 'z4C3PAx', 'u8jgyN3', 'V4cjtck', 'F1EZyWz', 'r0ITv0C', 'xYTdX3O'

flag_4k, flag_1080p, flag_720p, flag_sd = 'x5FjOZy', '2ptXKKa', '8ssOa9n', 'kkuMi2R'

provider_furk, provider_easynews, provider_alldebrid, provider_realdebrid, provider_premiumize, provider_folder = 'NJFLVCL', '5EKdDZi', 'oni7Zt9', '7yte1nF', 'kmNpjDb', 'a508B9o'

genre_action, genre_adventure, genre_animation, genre_comedy, genre_crime, genre_documentary = 'mOkM9Cs', 'SF329Ap', 'xCJdDW7', 'Xsb1iEl', 'cE3Rovc', 'DIfwy76'
genre_drama, genre_family, genre_fantasy, genre_foreign, genre_history, genre_horror = 'n0LmfJR', 'UVc9gws', 'Y4Y3EMn', 'HUN7FxK', 'J5EM9MB', 'SCJriF0'
genre_kids, genre_music, genre_mystery, genre_news, genre_reality, genre_romance = 'cMjxdqe', 'Qi9NcWi', '7GCK5Tg', 'CjDP92M', 'NZTCRcM', '5OZRqUX'
genre_scifi, genre_soap, genre_talk, genre_thriller, genre_war, genre_western = 'CPanVlY', 'RpDSmbX', 'DB5KHJf', 'ObKPLhE', 'MWqQbMF', 'MU8LKTK'

network_disney, network_disneyxd, network_abc, network_bbcamerica, network_nbc, network_nickelodeon = 'ZCgEkp6', 'PAJJoqQ', 'qePLxos', 'TUHDjfl', 'yPRirQZ', 'OUVoqYc'
network_pbs, network_cbs, network_fox, network_thewb, network_bet, network_usanetwork = 'r9qeDJY', '8OT8igR', '6vc0Iov', 'rzfVME6', 'ZpGJ5UQ', 'Doccw9E'
network_cbc, network_atx, network_mtv, network_lifetime, network_nickjr, network_tnt = 'unQ7WCZ', 'JshJYGN', 'QM6DpNW', 'tvYbhen', 'leuCWYt', 'WnzpAGj'
network_natgeo, network_comedycentral, network_hbo, network_spike, network_showtime, network_cartoonnetwork = 'XCGNKVQ', 'ko6XN77', 'Hyu8ZGq', 'BhXYytR', 'SawAYkO', 'zmOLbbI'
network_history, network_tlc, network_tbs, network_thecw, network_bravo, network_e, network_discoveryplus = 'LEMgy6n', 'c24MxaB', 'RVCtt4Z', 'Q8tooeM', 'TmEO3Tn', '3Delf9f', 'ukz1nOG'
network_syfy, network_adultswim, network_animalplanet, network_ctv, network_ane, network_vh1 = '9yCq37i', 'jCqbRcS', 'olKc4RP', 'qUlyVHz', 'xLDfHjH', 'IUtHYzA'
network_amc, network_crackle, network_wgnamerica, network_travel, network_netflix, network_audience = 'ndorJxi', '53kqZSY', 'TL6MzgO', 'mWXv7SF', 'jI5c3bw', '5Q3mo5A'
network_sundancetv, network_starz, network_cinemax, network_trutv, network_hallmark, network_tvland = 'qldG5p2', 'Z0ep2Ru', 'zWypFNI', 'HnB3zfc', 'zXS64I8', '1nIeDA5'
network_amazon, network_freeform, network_bbc1, network_bbc2, network_bbc3, network_bbc4 = 'ru9DDlL', 'f9AqoHE', 'u8x26te', 'SKeGH1a', 'SDLeLcn', 'PNDalgw'
network_sky1, network_itv, network_channel4, network_channel5, network_e4, network_hgtv = 'xbgzhPU', '5Hxp5eA', '6ZA9UHR', '5ubnvOh', 'frpunK8', 'INnmgLT'
network_hulu, network_youtubered, network_discovery, network_disneyplus, network_appletvplus, network_acorntv = 'uSD2Cdw', 'ZfewP1Y', '8UrXnAB', 'DVrPgbM', 'fAQMVNp', 'fSWB5gB'
network_cbsallaccess, network_hbomax, network_dcuniverse, network_paramount, network_paramountplus, network_peacock,  = 'ZvaWMuU', 'mmRMG75', 'bhWIubn', 'ez3U6NV', 'dmUjWmU', '1JXFkSM'
