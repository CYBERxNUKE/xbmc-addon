======================
Indigo
======================

License
-------
This software is released under the [GPL 3.0 license] [1].
[1]: http://www.gnu.org/licenses/gpl-3.0.html

Contribution
------------

* Please follow the [PEP-8 Guidelines](https://www.python.org/dev/peps/pep-0008) when contributing new code or modifying
already existing one
