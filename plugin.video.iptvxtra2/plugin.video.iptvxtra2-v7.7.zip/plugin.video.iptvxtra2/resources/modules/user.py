import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLmlwdHZ4dHJhMg==')

name = b.b64decode('SVBUVlh0cmEgSUk=')

port = b.b64decode('ODA=')

ch_list = b.b64decode('aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL2tlbnMxMy9FUEcvbWFzdGVyL2NoX2xpc3QuanNvbg==')

#xEPGurl = b.b64decode("aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL2tlbnMxMy9FUEcvbWFzdGVyL2d1aWRlX2tzLnhtbA==")
